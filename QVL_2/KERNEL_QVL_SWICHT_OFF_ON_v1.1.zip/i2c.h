#ifndef I2C_AVR_328P
#define I2C_AVR_328P
void ERROR_I2C();
void START_COMUNICATION_I2C();
void ENABLE_I2C_NOT_PULL_UP(int VELOCIDAD_DEL_I2C,int TWPS_1,int TWPS_0);
void ENABLE_I2C_PULL_UP(uint8_t VELOCIDAD_DEL_I2C,int TWPS_1,int TWPS_0);
void ESPERA_I2C();
unsigned char READ_I2C_ACK();
unsigned char READ_I2C_NACK();
uint8_t ESTATUS_I2C();
void STOP_COMUNICATION_I2C();
void WRITE_I2C(unsigned char ADDRESS_I2C_BIT_WRITE_BIT_READ);

unsigned char READ_I2C_ACK(void){
unsigned char DATA_W_R;
DATA_W_R=TWDR;
TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWEA);
return DATA_W_R;}

unsigned char READ_I2C_NACK(void){
unsigned char DATA_W_R;
DATA_W_R=TWDR;
TWCR=(1<<TWINT)|(1<<TWEN);
return DATA_W_R;}

void WRITE_I2C(unsigned char ADDRESS_I2C_BIT_WRITE_BIT_READ){
TWDR=ADDRESS_I2C_BIT_WRITE_BIT_READ;
TWCR=(1<<TWINT)|(1<<TWEN);}

void START_COMUNICATION_I2C(void){	
TWCR=(1<<TWINT)|(1<<TWSTA)|(1<<TWEN);}

void ENABLE_I2C_PULL_UP(uint8_t VELOCIDAD_DEL_I2C,int TWPS_1,int TWPS_0){
DDRC&=(0<<DDC4)|(0<<DDC5);
PORTC|=(1<<PORTC5)|(1<<PORTC4);
if((TWPS_1==0)&&(TWPS_0==0)){
TWSR|=(1<<TWPS0)|(1<<TWPS1);}else{
if((TWPS_1==0)&&(TWPS_0==1)){
TWSR|=(1<<TWPS0)|(0<<TWPS1);}else{
if((TWPS_1==1)&&(TWPS_0==0)){
TWSR|=(0<<TWPS0)|(1<<TWPS1);}else{
if((TWPS_1==1)&&(TWPS_0==1)){
TWSR|=(1<<TWPS0)|(1<<TWPS1);}}}}
TWBR=VELOCIDAD_DEL_I2C;
TWCR|=(1<<TWEN);}

void ENABLE_I2C_NOT_PULL_UP(int VELOCIDAD_DEL_I2C,int TWPS_1,int TWPS_0){
DDRC&=(0<<DDC4)|(0<<DDC5);
/*DDRC|=(1<<DDC3);*/
PORTC&=(0<<PORTC5)|(0<<PORTC4);
/*PORTC|=(1<<PORTC3);*/
if((TWPS_1==0)&&(TWPS_0==0)){
TWSR|=(1<<TWPS0)|(1<<TWPS1);}else{
if((TWPS_1==0)&&(TWPS_0==1)){
TWSR|=(1<<TWPS0)|(0<<TWPS1);}else{
if((TWPS_1==1)&&(TWPS_0==0)){
TWSR|=(0<<TWPS0)|(1<<TWPS1);}else{
if((TWPS_1==1)&&(TWPS_0==1)){
TWSR|=(1<<TWPS0)|(1<<TWPS1);}}}}
TWBR=VELOCIDAD_DEL_I2C;
TWCR|=(1<<TWEN);}

void ESPERA_I2C(void){
while(!(TWCR&(1<<TWINT))){}}
	
void ERROR_I2C(void){}
	
uint8_t ESTATUS_I2C(void){
uint8_t DATE_ESTATUS_I2C;
DATE_ESTATUS_I2C=TWSR&0xf8;
ERROR_I2C();
return DATE_ESTATUS_I2C;}

void STOP_COMUNICATION_I2C(void){
TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWSTO);}

#endif